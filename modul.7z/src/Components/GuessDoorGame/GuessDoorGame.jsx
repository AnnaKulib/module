import { useDispatch, useSelector } from "react-redux";
import { getPlayer, setCurrentGame, updateBalance } from "../../features/player/playerSlice";
import { useState } from "react";

const GuessDoorGame = () => {
  const dispatch = useDispatch();
  const player = useSelector(getPlayer);
  const [selectedDoor, setSelectedDoor] = useState(null);
  const [result, setResult] = useState(null);
  const bet = player.balance * 0.05;

  const handleSelectDoor = (doorNumber) => {
    setSelectedDoor(doorNumber);
  };

  const handlePlayAgain = () => {
    setSelectedDoor(null);
    setResult(null);
  };

  const handleGuessDoor = () => {
    if (selectedDoor != null) {
      const winningDoor = Math.floor(Math.random() * 3) + 1;
      const win = selectedDoor === winningDoor;
      dispatch(setCurrentGame({
        id: "1",
        winningDoor,
        selectedDoor,
        bet,
        result: win ? "win" : "lose"
    }));
      dispatch(updateBalance(win ? bet : -bet));
      setResult(win ? "win" : "lose");
    }
  };

  return (
    <div>
      {player.balance < player.deposit * 0.05 ? (
        <p>На вашому балансі недостатньо коштів для гри</p>
      ) : (
        <>
          {!selectedDoor ? (
            <div>
              <p>Оберіть двері:</p>
              <button onClick={() => handleSelectDoor(1)}>Двері 1</button>
              <button onClick={() => handleSelectDoor(2)}>Двері 2</button>
              <button onClick={() => handleSelectDoor(3)}>Двері 3</button>
            </div>
          ) : (
            <div>
              <p>Ваш вибір: {selectedDoor}</p>
              <button onClick={handleGuessDoor}>Вгадав?</button>
            </div>
          )}
          {result && (
            <div>
              <p>{result === "win" ? "Ви виграли" : "Ви програли :("}</p>
              <p>Виграшні двері: {player.currentGame.winningDoor}</p>
              <p>Ставка: {player.currentGame.bet}$</p>
              <button onClick={handlePlayAgain}>Обрати знову</button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default GuessDoorGame;
