export { default } from "./GuessDoorGame";
