import { useDispatch, useSelector } from "react-redux";
import { getPlayer, updateBalance, setCurrentGame } from "../../features/player/playerSlice";
import { useState } from "react";

const CoinFlipGame = () => {
    const dispatch = useDispatch();
    const player = useSelector(getPlayer);
    const [choice, setChoice] = useState("");
    const [result, setResult] = useState("");
    const bet = player.balance * 0.05;

    const handleChoice = (choice) => {
    setChoice(choice);
};

    const handlePlayAgain = () => {
        setChoice("");
        setResult("");
    };

    const handleFlipCoin = () => {
        if (choice) {
        const isHeads = Math.random() < 0.5;
        const win = (choice === "heads" && isHeads) || (choice === "tails" && !isHeads);
        dispatch(setCurrentGame({
            id: "1",
            choice,
            isHeads,
            bet,
            result: win ? "win" : "lose"
        }));

        dispatch(updateBalance(win ? bet : -bet));
        setResult(win ? "win" : "lose");
        }
    };

    return (
        <div>
            {player.balance < player.deposit * 0.05 ? (
            <p>На вашому балансі недостатньо коштів для гри</p>
            ) : (
            <>
            {!choice ? (
            <div>
            <button onClick={() => handleChoice("heads")}>Орел</button>
            <button onClick={() => handleChoice("tails")}>Решка</button>
            </div>
            ) : (
            <div>
            <p>Ваш вибір {choice}</p>
            <button onClick={handleFlipCoin}>Підкинути монетку</button>
            </div>
            )}
            {result && (
            <div>
            <p>{result === "win" ? "Ви виграли" : "Ви програли :("}</p>
            <p>Переможець: {player.currentGame.isHeads ? "Heads" : "Tails"}</p>
            <p>Ставка: {player.currentGame.bet}$</p>
            <button onClick={handlePlayAgain}>Підкинути знову</button>
            </div>
            )}
            </>
            )}
        </div>
    );
};

export default CoinFlipGame;

