export { default } from "./CoinFlipGame";
