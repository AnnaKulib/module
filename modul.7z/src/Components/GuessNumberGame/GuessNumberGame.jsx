import { useDispatch, useSelector } from "react-redux";
import { getPlayer, updateBalance, setCurrentGame } from "../../features/player/playerSlice";
import { useState } from "react";

const GuessNumberGame = () => {
    const dispatch = useDispatch();
    const player = useSelector(getPlayer);
    const [selectedNumber, setSelectedNumber] = useState(null);
    const [result, setResult] = useState(null);
    const bet = player.balance * 0.05;

    const handleSelectNumber = (number) => {
        setSelectedNumber(number);
    };

    const handlePlayAgain = () => {
        setSelectedNumber(null);
        setResult(null);
    };

    const handleGuessNumber = () => {
        if (selectedNumber != null) {
            const winningNumber = Math.floor(Math.random() * 10) + 1;
            const win = selectedNumber === winningNumber;
            dispatch(setCurrentGame({
                id: "3",
                winningNumber,
                selectedNumber,
                bet,
                result: win ? "win" : "lose"
            }));
            dispatch(updateBalance(win ? (bet * 10) : -bet));
            setResult(win ? "win" : "lose");
        }
    };

    return (
        <div>
            {player.balance < player.deposit * 0.05 ? (
              <p>На вашому балансі недостатньо коштів для гри</p>
            ) : (
              <>
                {!selectedNumber ? (
                  <div>
                    <p>Оберіть номер:</p>
                    <button onClick={() => handleSelectNumber(1)}>1</button>
                    <button onClick={() => handleSelectNumber(2)}>2</button>
                    <button onClick={() => handleSelectNumber(3)}>3</button>
                    <button onClick={() => handleSelectNumber(4)}>4</button>
                    <button onClick={() => handleSelectNumber(5)}>5</button>
                    <button onClick={() => handleSelectNumber(6)}>6</button>
                    <button onClick={() => handleSelectNumber(7)}>7</button>
                    <button onClick={() => handleSelectNumber(8)}>8</button>
                    <button onClick={() => handleSelectNumber(9)}>9</button>
                    <button onClick={() => handleSelectNumber(10)}>10</button>
                  </div>
                ) : (
                  <div>
                    <p>Обраний вами номер {selectedNumber}</p>
                      <button onClick={handleGuessNumber}>Вгадав?</button>
                  </div>
                )}
                {result && (
                  <div>
                    <p>{result === "win" ? "Ви виграли" : "Ви програли :("}</p>
                    <p>Виграшний номер: {player.currentGame.winningNumber}</p>
                    <p>Ставка: {player.currentGame.bet}$</p>
                    <button onClick={handlePlayAgain}>Обрати знову</button>
                  </div>
                )}
            </>
            )}
        </div>
    );
};

export default GuessNumberGame;