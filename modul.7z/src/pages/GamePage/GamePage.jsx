import React from "react";
import { useParams } from "react-router-dom";
import { getPlayer } from "../../features/player/playerSlice";
import { useSelector } from "react-redux";
import _ from "lodash";
import gamesData from "../../gameData.json";
import CoinFlipGame from "../../Components/CoinFlipGame";
import GuessDoorGame from "../../Components/GuessDoorGame";
import GuessNumberGame from "../../Components/GuessNumberGame";
import s from "./GamePage.module.css"

const GamePage = () => {
  const player = useSelector(getPlayer);
  const { id } = useParams();
  
  const game = _.find(gamesData.games, { id: id });
  
  const visibleGame = () => {
    switch (id) {
      case "1":
        return <CoinFlipGame />
        break;
      case "2":
        return <GuessDoorGame />
        break;
      case "3":
      return <GuessNumberGame />
      break;
      default:
        break;
    }
  }

  return (
    <div>
      <header className={s.header}>
        <img className={s.img} src={player.logo?.dataUrl ?? ''} alt="logo" />
        <p><span>{player.name}</span> <span>Депозит: {player.deposit}$</span> <span>Баланс: {player.balance}$</span></p>
        <button type="button">Заново</button>
      </header>
      <h1>{game.name}</h1>
      <p>{game.description}</p>
      {visibleGame()}
    </div>
  );
};

export default GamePage;



      {/* <Routes>
        <Route path="/games/1" element={<CoinFlipGame game={game} />} />
        <Route path="/game/:id/guess-door" element={<GuessDoorGame game={game} />} />
      </Routes> */}
      {/* <ul>
        {_.map(game.answers, (answer, key) => (
          <li key={key}>
            <span>{key}:</span> {answer}
          </li>
        ))}
      </ul> */}