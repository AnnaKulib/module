export { default } from "./GamePage";
