export { default } from "./GamesPage";
