import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { getPlayer, setCurrentGame } from "../../features/player/playerSlice";
import s from "./GamesPage.module.css";

const GamesPage = () => {
    const player = useSelector(getPlayer); 

    return (
    <div className={s.section}>
        <header className={s.header}>
            <img className={s.img} src={player.logo?.dataUrl ?? ''} alt="logo" />
            <p><span>{player.name}</span> <span>Депозит: {player.deposit}$</span> <span>Баланс: {player.balance}$</span></p>
        <button type="button">Заново</button>
        </header>
        <div className={s.main}>
            <div>
                <div className={s.wrapper}>
                <h1>Доступні ігри</h1>   
                </div>
                <div className={s.wrapper}>
                <Link to="/games/1"><div className={s.gameCard}><h2>Монетка</h2><img className={s.img} src="https://image.pngaaa.com/770/50770-middle.png" alt="game logo" /></div></Link>
                <Link to="/games/2"><div className={s.gameCard}><h2>Вгадай двері</h2><img className={s.img} src="https://image.pngaaa.com/770/50770-middle.png" alt="game logo" /></div></Link>
                <Link to="/games/3"><div className={s.gameCard}><h2>Вгадай число</h2><img className={s.img} src="https://image.pngaaa.com/770/50770-middle.png" alt="game logo" /></div></Link>
                </div>
                <div className={s.wrapper}>
                <p>Мета гри - подвоїти початковий депозит, граючи в ігри</p>
                </div>
            </div>
            <div className={`${s.wrapper} ${s.flexColBlock}`}>
                <h2>Результати</h2>
                <p>Монетка:</p>
                <p>Вгадай двері:</p>
                <p>Вгадай число:</p>
            </div>
        </div>
    </div>
    )
}

export default GamesPage;