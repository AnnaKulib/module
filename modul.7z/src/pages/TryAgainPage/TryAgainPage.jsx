import React from "react";
const TryAgainPage = () => {
    return <p>TryAgainPage</p>
}

export default TryAgainPage;