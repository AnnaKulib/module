import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { setPlayer } from '../../features/player/playerSlice';
import s from "./MainPage.module.css";

const MainPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [deposit, setDeposit] = useState(0);
  const [logo, setLogo] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(setPlayer({ name, deposit: Number(deposit), balance: Number(deposit), logo }));
    navigate('/games');
  };

  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
    const logo = {
      dataUrl: reader.result,
    };
    setLogo(logo)
  };
  reader.readAsDataURL(file);
  }

  const isSubmitDisabled = !name || deposit <= 0;

  return (
    <div className={s.section}>
      <form  noValidate autoComplete="off">
    </form>
      <h1>MainPage</h1>
      <form onSubmit={handleSubmit} className={s.form}>
        <label>
          <input className={s.inputFile} type="file" accept="image/*" title="Ваш логотип" onChange={handleLogoChange}/>
        </label>
        <label>
          <input className={s.input} type="text" placeholder="Ваше ім'я" value={name} onChange={(e) => setName(e.target.value)} />
        </label>
        <label>
          Початковий депозит:
          <input className={s.input} type="number" value={deposit} onChange={(e) => setDeposit(e.target.value)} min="1" />
        </label>
        <button className={s.button} type="submit" disabled={isSubmitDisabled}>
          Почати
        </button>
      </form>
    </div>
  );
};

export default MainPage;
