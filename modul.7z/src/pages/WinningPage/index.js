export { default } from "./WinningPage";
