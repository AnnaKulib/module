import React from "react";
const WinningPage = () => {
    return <p>WinningPage</p>
}

export default WinningPage;