import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  name: "",
  deposit: 0,
  balance: 0,
  games: [],
  currentGame: {},
};

export const playerSlice = createSlice({
  name: "player",
  initialState,
  reducers: {
    setPlayer: (state, action) => {
      return action.payload;
    },
    setGames: (state, action) => {
      state.games = action.payload;
    },
    setCurrentGame: (state, action) => {
      state.currentGame = action.payload;
    },
    updateBalance: (state, action) => {
      const amount = action.payload;
      if (amount != null) {
        state.balance += amount;
      }
    },
  },
});

export const { setPlayer, setGames, setCurrentGame, updateBalance } =
  playerSlice.actions;

export const getPlayer = (state) => state.player;

export default playerSlice.reducer;
