import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  balance: 0,
  games: [],
  currentGame: {},
};

export const gameSlice = createSlice({
  name: "game",
  initialState,
  reducers: {
    setGames: (state, action) => {
      state.games = action.payload;
    },
    setCurrentGame: (state, action) => {
      state.currentGame = action.payload;
    },
  },
});

export const { setGames, setCurrentGame } = gameSlice.actions;

export const getGame = (state) => state.game;

export default gameSlice.reducer;
